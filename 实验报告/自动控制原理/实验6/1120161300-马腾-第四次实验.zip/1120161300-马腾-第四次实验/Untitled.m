clear;
clc;
A=[-2 -1 1;1 0 1;-1 0 1];
[V,D]=eig(A)